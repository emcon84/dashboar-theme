---

## 📄 3. **LICENSE.md (MIT)**

```markdown
MIT License

Copyright (c) 2025 Emiliano

Permission is hereby granted, free of charge, to any person obtaining a copy...
(→ podés copiar el texto completo desde [aquí](https://opensource.org/license/mit/))
```
